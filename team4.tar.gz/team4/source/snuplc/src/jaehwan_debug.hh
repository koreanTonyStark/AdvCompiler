string debugOP(int num)
{
 switch(num)
 {
  case opAdd:
    return "opAdd";
    break;
  case opSub:
    return "opSub";
    break;
  case opMul:
    return "opMul";
    break;
  case opDiv:
    return "opDiv";
    break;
  case opAnd:
    return "opAnd";
    break;
  case opOr:
    return "opOr";
    break;
  case opNeg:
    return "opNeg";
    break;
  case opPos:
    return "opPos";
    break;
  case opNot:
    return "opNot";
    break;
  case opAddress:
    return "opAddress";
    break;
  case opAssign:
    return "opAssign";
    break;
  case opDeref:
    return "opDeref";
    break;
  case opCast:
    return "opCast";
    break;
  case opGoto:
    return "opGoto";
    break;
  case opEqual:
    return "opEqual";
    break;
  case opNotEqual:
    return "opNotEqual";
    break;
  case opLessThan:
    return "opLessThan";
    break;
  case opLessEqual:
    return "opLessEqual";
    break;
  case opBiggerThan:
    return "opBiggerThan";
    break;
  case opBiggerEqual:
    return "opBiggerEqual";
    break;
  case opCall:
    return "opCall";
    break;
  case opReturn:
    return "opReturn";
    break;
  case opParam:
    return "opParam";
    break;
  case opLabel:
    return "opLabel";
    break;
  case opNop:
    return "opNop";
    break;
          

 } 
}

